/*
 * この画面は JavaScript スクラッチパッドです。
 *
 * JavaScript を入力して、右クリックまたは [実行] メニューを選択してください。
 * 1. 実行: 選択したコードを実行します。(Ctrl+R)
 * 2. 調査: 実行結果をオブジェクトインスペクターで表示します。(Ctrl+I)
 * 3. 表示: 選択したコードの後ろに、実行結果をコメント形式で挿入します。(Ctrl+L)
 */


//12月6日の学習と宿題
//18T2068A 佐竹柊路
//
/*
console.log('こんにちは、スクラッチパッド');
*/

/*
var yourname = 'しゅうじ';
console.log('こんにちは、' +yourname +'さん');
*/

/*
//ex2.1
var yourname ='しゅうじ';
window.alert('こんにちは、'+yourname+'さん！
             ');
*/  

/*
function greeting(name){console.log('こんにちは、
'+name+'さん！')}
greeting('柊路');
greeting('佐竹');
*/

//ex2.2
/*
function multiply(a,b) {console.log(a*b);};
multiply(2,3);
*/

//ex2.3
/*
for (let i=0; i<10; i++){
console.log(i**2);
}
*/

//ex2.4
/*
for (let i=6; i<=31; i+=7){
console.log(i);
}
*/

/*
for (let i=0; i<10; i++){
  if (i%2==0){
    console.log(i+'は偶数です');
  }else{
    console.log(i+'は奇数です')
  }
}
*/

/*
document.getElementById('mainPhoto');
console.log(document.getElementById('mainPhoto'));
var largeImg = document.getElementById('mainPhoto');
console.log(largeImg);
*/

//ex3.5
/*
document.getElementById('thumbnails');
console.log(document.getElementById('thumbnails'));
*/
